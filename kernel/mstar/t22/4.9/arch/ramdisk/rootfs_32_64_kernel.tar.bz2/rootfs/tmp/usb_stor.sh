sync
umount -l /dev/mmcblk0p1
insmod /tmp/g_file_storage.ko file=/dev/mmcblk0p1 removable=y
