#!/bin/sh
mkdir -p /mnt/ubifs1
mknod /dev/ubi0 c 253 0
ubimkvol /dev/ubi0 -m -N ubifs1
mount -t ubifs -o no_chk_data_crc,compr=none ubi0:ubifs1 /mnt/ubifs1
echo "mount nand flash on /mnt/ubifs1"


